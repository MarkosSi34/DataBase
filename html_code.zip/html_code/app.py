# -*- coding: utf-8 -*-
"""
Created on Wed May 25 13:26:48 2022

@author: Markos
"""
from flask import Flask, render_template, request
from flask_mysqldb import MySQL

app = Flask(__name__)
app.config['MYSQL_HOST'] = 'localhost'
app.config['MYSQL_PORT'] = 3306
app.config["MYSQL_USER"] = "root"
app.config["MYSQL_PASSWORD"] = ""
app.config["MYSQL_DB"] = "project141"
app.config["MYSQL_CURSORCLASS"] = "DictCursor"
mysql = MySQL(app)


@app.route("/")
def database():
    return render_template('database.html')

@app.route("/Erg3_1", methods=["GET", "POST"])
def Erg3_1():
    cur=mysql.connection.cursor()
    rv=[]
    cur.execute('''SELECT
	ID,
    FistName,
    LastName
FROM stelexos''')
    stelexos=cur.fetchall()
    if request.method=="POST":
        data=request.form
        d={'duration': '', 'stelexos1': '', 'sdate': ''}
        for key,value in data.items():
            d[key]=value   
        print(d)
        final_duration=d['duration']
        print("Διάρκεια={}".format(final_duration))
        final_stelexos=d['stelexos1']
        print("Στέλεχος={}".format(final_stelexos))
        final_startdate=d['sdate']
        print("Ημερομηνία={}".format(final_startdate))
        if final_duration != "" and final_stelexos != "" and final_startdate != "":
            print("abc")
            cur.execute('''SELECT	
	e.ID,
    e.Title,
    s.FistName as `Stel_name`,
    s.LastName as `Stel_last`,
    p.ID as `ID_pro`,
    p.Name,
    er.FirstName,
    er.LastName
FROM worksforergo w
	INNER JOIN ergo e ON w.ergo=e.ID
    INNER JOIN ereuniths er ON er.ID=w.ereuniths
    INNER JOIN stelexos s ON  s.ID=e.Stelexos AND s.ID={0}
    INNER JOIN programma p ON p.ID=e.Xorhgia
WHERE 
	YEAR(EndDate)-YEAR(StartDate)="{2}" AND StartDate>"{1}"
    '''.format(final_stelexos,final_startdate,final_duration))
            rv=cur.fetchall()
        elif final_duration != "" and final_stelexos != "":
            print("ab")
            cur.execute('''SELECT	
 	e.ID,
     e.Title,
     s.FistName as `Stel_name`,
     s.LastName as `Stel_last`,
     p.ID as `ID_pro`,
     p.Name,
     er.FirstName,
     er.LastName
 FROM worksforergo w
 	INNER JOIN ergo e ON w.ergo=e.ID
     INNER JOIN ereuniths er ON er.ID=w.ereuniths
     INNER JOIN stelexos s ON  s.ID=e.Stelexos AND s.ID={1}
     INNER JOIN programma p ON p.ID=e.Xorhgia
 WHERE 
 	YEAR(EndDate)-YEAR(StartDate)="{0}"
     '''.format(final_duration,final_stelexos))
            rv=cur.fetchall()
        elif final_stelexos != "" and final_startdate != "":
            print("bc")
            cur.execute('''SELECT	
   	e.ID,
       e.Title,
       s.FistName as `Stel_name`,
       s.LastName as `Stel_last`,
       p.ID as `ID_pro`,
       p.Name,
       er.FirstName,
       er.LastName
   FROM worksforergo w
   	INNER JOIN ergo e ON w.ergo=e.ID
       INNER JOIN ereuniths er ON er.ID=w.ereuniths
       INNER JOIN stelexos s ON  s.ID=e.Stelexos AND s.ID={0}
       INNER JOIN programma p ON p.ID=e.Xorhgia
   WHERE 
   	StartDate>"{1}"
       '''.format(final_stelexos,final_startdate))
            rv=cur.fetchall()
        elif final_duration != "" and final_startdate != "":
            print("ac")
            cur.execute('''SELECT	
 	e.ID,
     e.Title,
     s.FistName as `Stel_name`,
     s.LastName as `Stel_last`,
     p.ID as `ID_pro`,
     p.Name,
     er.FirstName,
     er.LastName
 FROM worksforergo w
 	INNER JOIN ergo e ON w.ergo=e.ID
     INNER JOIN ereuniths er ON er.ID=w.ereuniths
     INNER JOIN stelexos s ON  s.ID=e.Stelexos 
     INNER JOIN programma p ON p.ID=e.Xorhgia
 WHERE 
 	YEAR(EndDate)-YEAR(StartDate)="{0}" AND StartDate>"{1}"
     '''.format(final_duration,final_startdate))
            rv=cur.fetchall()
             
        elif  final_duration != "":
            print("a")
            cur.execute('''SELECT	
	e.ID,
    e.Title,
    s.FistName as `Stel_name`,
    s.LastName as `Stel_last`,
    p.ID as `ID_pro`,
    p.Name,
    er.FirstName,
    er.LastName
FROM worksforergo w
	INNER JOIN ergo e ON w.ergo=e.ID
    INNER JOIN ereuniths er ON er.ID=w.ereuniths
    INNER JOIN stelexos s ON  s.ID=e.Stelexos 
    INNER JOIN programma p ON p.ID=e.Xorhgia
WHERE 
	YEAR(EndDate)-YEAR(StartDate)="{}"
    '''.format(final_duration))
            rv=cur.fetchall()
        elif final_stelexos != "":
            print("b")
            cur.execute('''SELECT	
	e.ID,
    e.Title,
    s.FistName as `Stel_name`,
    s.LastName as `Stel_last`,
    p.ID as `ID_pro`,
    p.Name,
    er.FirstName,
    er.LastName
FROM worksforergo w
	INNER JOIN ergo e ON w.ergo=e.ID
    INNER JOIN ereuniths er ON er.ID=w.ereuniths
    INNER JOIN stelexos s ON  s.ID=e.Stelexos AND s.ID={}
    INNER JOIN programma p ON p.ID=e.Xorhgia
    '''.format(final_stelexos))
            rv=cur.fetchall()
        elif final_startdate != "":
            print("c")
            cur.execute('''SELECT	
	e.ID,
    e.Title,
    s.FistName as `Stel_name`,
    s.LastName as `Stel_last`,
    p.ID as `ID_pro`,
    p.Name,
    er.FirstName,
    er.LastName
FROM worksforergo w
	INNER JOIN ergo e ON w.ergo=e.ID
    INNER JOIN ereuniths er ON er.ID=w.ereuniths
    INNER JOIN stelexos s ON  s.ID=e.Stelexos 
    INNER JOIN programma p ON p.ID=e.Xorhgia
WHERE 
	StartDate>"{}"
    '''.format(final_startdate))
            rv=cur.fetchall()
        else:
            print("nada")
            cur.execute('''SELECT	
	e.ID,
    e.Title,
    s.FistName as `Stel_name`,
    s.LastName as `Stel_last`,
    p.ID as `ID_pro`,
    p.Name,
    er.FirstName,
    er.LastName
FROM worksforergo w
	INNER JOIN ergo e ON w.ergo=e.ID
    INNER JOIN ereuniths er ON er.ID=w.ereuniths
    INNER JOIN stelexos s ON  s.ID=e.Stelexos 
    INNER JOIN programma p ON p.ID=e.Xorhgia;''')
            rv=cur.fetchall()
    return render_template('Ερώτημα 3.1.html',result=rv,stelexos=stelexos)





@app.route("/Erg3_2")
def Erg3_2():
    cur = mysql.connection.cursor()
    cur.execute('''SELECT * FROM view1''')
    rv = cur.fetchall()
    return render_template('Ερώτημα 3.2.html',result=rv)

@app.route("/Erg3_2_view2")
def Erg3_2_v2():
    cur = mysql.connection.cursor()
    cur.execute('''SELECT * FROM view2''')
    rv = cur.fetchall()
    return render_template('Ερώτημα 3.2_view2.html',result=rv)

@app.route("/Erg3_3", methods=["GET","POST"])
def Erg3_3():
    cur = mysql.connection.cursor()
    rv=[]
    cur.execute('''SELECT NAME FROM episthmoniko_pedio''')
    select=cur.fetchall()
    if request.method=="POST":
        final=request.form.get("pedio")
        cur.execute('''SELECT
    e.ID as `ergo_ID`,
    e.Title,
    er.ID,
    er.FirstName,
    er.LastName
FROM
    pediorelation pr
    INNER JOIN ergo e ON (pr.episthmoniko_pedio="{}" AND pr.ergo=e.ID)
    INNER JOIN worksforergo w ON w.ergo=e.ID
    INNER JOIN ereuniths er ON er.ID=w.ereuniths
WHERE
    EndDate > CURRENT_DATE() AND YEAR(CURRENT_DATE())-YEAR(StartDate)<=1

;'''.format(final))
        rv=cur.fetchall()
    return render_template('Ερώτημα 3.3.html',result=rv,select=select)

@app.route("/Erg3_4")
def Erg3_4():
    cur=mysql.connection.cursor()
    cur.execute('''CREATE TEMPORARY TABLE temp(
SELECT
    	YEAR(e1.StartDate) as `Year1`,
        org.ID as `organi_ID`,
        org.Name,
        COUNT(org.ID) as `Count`
FROM
	organization org
	JOIN ergo e1 On e1.Organization=org.ID

GROUP BY
    org.ID,`Year1`
HAVING
    `Count`>0
)''')
    cur.execute('''SELECT 
	t1.organi_ID,
    t1.Name,
    t1.Count 
FROM
	temp t1
    JOIN temp t2 on t1.organi_ID=t2.organi_ID
WHERE
	t1.Year1=t2.Year1 + 1 AND t1.Count=t2.Count''')
    rv=cur.fetchall()
    return render_template('Ερώτημα 3.4.html',result=rv)


@app.route("/Erg3_5")
def Erg3_5():
    cur=mysql.connection.cursor()
    cur.execute('''SELECT
    p1.episthmoniko_pedio as `Pedio1`,
    p2.episthmoniko_pedio as `Pedio2`,
    COUNT(p1.episthmoniko_pedio) as `count`
FROM
    pediorelation p1, pediorelation p2
WHERE
	p1.episthmoniko_pedio < p2.episthmoniko_pedio AND p1.ergo=p2.ergo
GROUP BY
	p1.episthmoniko_pedio,p2.episthmoniko_pedio
ORDER BY
    'count' DESC
LIMIT 3
;''')
    rv=cur.fetchall()
    return render_template('Ερώτημα 3.5.html',result=rv)


@app.route("/Erg3_6")
def Erg3_6():
    cur = mysql.connection.cursor()
    cur.execute('''SELECT
    ereuniths as 'ID',
    FirstName,
    LastName,
    COUNT(ereuniths) as 'count'
FROM
    worksforergo w
    INNER JOIN ereuniths r ON r.ID=w.ereuniths
    INNER JOIN ergo e ON e.ID=w.ergo
WHERE
    YEAR(CURRENT_DATE())-YEAR(DoBirth)<40 AND EndDate>CURRENT_DATE()
GROUP BY
    ereuniths
ORDER BY
    'count' DESC;
''')
    rv = cur.fetchall()
    return render_template('Ερώτημα 3.6.html', result=rv)


@app.route("/Erg3_7")
def Erg3_7():
    cur = mysql.connection.cursor()
    cur.execute('''SELECT
	s.ID as `stel_ID`,
    s.FistName,
    s.LastName,
    e.ID,
    e.Title,
    e.Funding
FROM
   ergo e 
   INNER JOIN stelexos s ON e.Stelexos=s.ID
ORDER BY
    Funding DESC
LIMIT 5
;''')
    rv = cur.fetchall()
    return render_template('Ερώτημα 3.7.html',result=rv)


@app.route("/Erg3_8")
def Erg3_8():
    cur = mysql.connection.cursor()
    cur.execute('''SELECT
    ereuniths as 'ID',
    FirstName,
    LastName,
    COUNT(w.ereuniths) as 'count'
FROM
    paradoteo p, ergo e 

    INNER JOIN worksforergo w ON e.ID=w.ergo
    INNER JOIN ereuniths r ON r.ID=w.ereuniths
WHERE
   p.ergo<>e.ID
GROUP BY
    ereuniths
HAVING count>=5
;    ''')
    rv = cur.fetchall()
    return render_template('Ερώτημα 3.8.html',result=rv)
